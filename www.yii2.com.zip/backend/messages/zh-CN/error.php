<?php
/**
 * Created by PhpStorm.
 * User: funson
 * Date: 2014/10/25
 * Time: 10:33
 */

return [
    'error' => '错误',

];