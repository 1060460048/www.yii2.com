<?php
/**
 * Created by PhpStorm.
 * User: funson
 * Date: 2014/10/25
 * Time: 10:33
 */

return [

    'Name' => '名称',
    'Description' => '描述',
    'Operation List' => '权限列表',

    'basic' => '基本',
    'user' => '管理员',
    'role' => '角色',

    'backendLogin' => '后台登录',

    'viewUser' => '查看管理员',
    'createUser' => '创建管理员',
    'updateUser' => '更新管理员',
    'deleteUser' => '删除管理员',

    'viewRole' => '查看角色',
    'createRole' => '创建角色',
    'updateRole' => '更新角色',
    'deleteRole' => '删除角色',

];