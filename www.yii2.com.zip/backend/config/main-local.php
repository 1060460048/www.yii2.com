<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'NDro-yg-6Ow1u4b9wOaU5s4TPZwuj5U7',
        ],
    ],
];

if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
        'generators' => [
            'crud'   => [
                'class'     => 'yii\gii\generators\crud\Generator',
                'templates' => ['mycrud' => '@backend/templates/mycrud']
            ],
            'model'   => [
                'class'     => 'yii\gii\generators\model\Generator',
                'templates' => ['mymodel' => '@backend/templates/mymodel']
            ]
        ]
    ];
}

return $config;
