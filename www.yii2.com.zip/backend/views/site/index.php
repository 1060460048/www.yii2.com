<?php

/* @var $this yii\web\View */

$this->title = '欢迎进入管理后台';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-index">
    <h3>欢迎来到管理后台！</h3>
    
</div>
